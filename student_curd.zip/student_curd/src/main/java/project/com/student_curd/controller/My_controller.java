package project.com.student_curd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import project.com.student_curd.my_entity.My_entity;
import project.com.student_curd.service.service;

@RestController
@RequestMapping("/here")
public class My_controller {
	@Autowired
	service serv;

	@PostMapping("/add")
	public void addemp(My_entity a) {
		serv.addemp(a);
	}

	@GetMapping("/delete")
	public void deleteemp(@RequestParam(name = "id") int id) {
		serv.deleteemp(id);
	}

	@GetMapping("/show")
	public List<My_entity> showemp() {
		return serv.showemployee();
	}
}
