package project.com.student_curd.my_entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Estudent")
public class My_entity {
	@Id
	int id;
	String name;
	int rollno;
	String division;

	public My_entity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public My_entity(int id, String name, int rollno, String div) {
		super();
		this.id = id;
		this.name = name;
		this.rollno = rollno;
		this.division = div;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getDiv() {
		return division;
	}

	public void setDiv(String div) {
		this.division = div;
	}

}
