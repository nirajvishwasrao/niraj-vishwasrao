package project.com.student_curd.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import project.com.student_curd.my_entity.My_entity;

@Repository
public interface Userrepositary extends JpaRepository<My_entity, Integer> {

}
