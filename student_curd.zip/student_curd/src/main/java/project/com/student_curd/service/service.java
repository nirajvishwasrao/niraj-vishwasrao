package project.com.student_curd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import project.com.student_curd.my_entity.My_entity;
import project.com.student_curd.repositary.Userrepositary;

@Service
public class service {
	@Autowired
	Userrepositary repo;

	public void addemp(My_entity a) {

		repo.save(a);

	}

	public void deleteemp(int id) {
		repo.deleteById(id);
	}

	public List<My_entity> showemployee() {
		return   repo.findAll();
	}
}
