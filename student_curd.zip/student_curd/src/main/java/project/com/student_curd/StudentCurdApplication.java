package project.com.student_curd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import jakarta.persistence.Entity;

@SpringBootApplication
//@EnableJpaRepositories(basePackages = "project.com.student_curd.repositary")
//@EntityScan(basePackages = "project.com.student_curd.my_entity")
public class StudentCurdApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentCurdApplication.class, args);
	}

}
