package project.com.student_curd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentCurdApplicationTests {

	@Test
	void contextLoads() {
	}

}
